<?= $this->include('partials/topbar') ?>

<?= $this->include('partials/sidebar') ?>
<!-- @@include("horizontal.html") -->